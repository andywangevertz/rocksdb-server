#include "build_version.h"
const char* rocksdb_build_git_sha = "rocksdb_build_git_sha:7d21b1dcf533eda05a9af4bf8f018469b09dc580";
const char* rocksdb_build_git_date = "rocksdb_build_git_date:2022-04-23";
const char* rocksdb_build_compile_date = __DATE__;
